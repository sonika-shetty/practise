package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class SecondTest extends BaseTest {


	@Test
	public void TestGoogle() throws Exception
	{
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.google.com");
		driver.findElement(By.name("q")).sendKeys("Seven Wonders of the world", Keys.ENTER);
		System.out.println("Title of the Page : " + driver.getTitle());
		Thread.sleep(2000);
		driver.quit();
	}
	
	@Test
	public void TestFb() throws Exception
	{
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.facebook.com");
		driver.findElement(By.name("email")).sendKeys("venugopal@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("12345");
		Thread.sleep(2000);
		driver.findElement(By.name("login")).submit();
		Thread.sleep(2000);
		driver.quit();
	}	
}