package com.testing;

import org.testng.annotations.Test;

public class FirstTest extends BaseTest {

	@Test
	public void TestCase1()
	{
		System.out.println("This is TestNG Case 1");
	}
	
	@Test
	public void TestCase2()
	{
		System.out.println("This is TestNg Case 2");
	}
	
}
